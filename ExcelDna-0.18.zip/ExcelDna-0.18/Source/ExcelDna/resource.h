//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ExcelDna.rc
//
#define IDS_MY_FIRST                    107
#define IDS_MSG_TITLE                   111
#define IDS_MSG_TEMPLATE                112
#define IDS_MSG_HEADER_NEEDCLR20        113
#define IDS_MSG_BODY_LOADMSCOREE        114
#define IDS_MSG_FOOTER_ENSURECLR20      115
#define IDS_MSG_BODY_CORBINDFAILED      116
#define IDS_MSG_FOOTER_ENSURECLR20ANDLOAD 117
#define IDS_MSG_FOOTER_UNEXPECTED       118
#define IDS_MSG_BODY_HOSTSTART          119
#define IDS_MSG_BODY_OLDVERSION         120
#define IDS_MSG_FOOTER_OLDVERSION       121
#define IDS_MSG_BODY_NONET20            122
#define IDS_MSG_BODY_NOCORBIND          123
#define IDS_MSG_BODY_NOCORVERSION       124
#define IDS_MSG_BODY_CORVERSIONFAILED   125
#define IDS_MSG_HRESULT                 126
#define IDS_MSG_BODY_UNKNOWNLOADFAIL    127
#define IDS_MSG_FOOTER_REVIEWADDINS     128
#define IDS_MSG_BODY_WRONGVERSIONLOADED 129
#define IDS_MSG_HEADER_APPDOMAIN        130
#define IDS_MSG_BODY_APPDOMAINSETUP     131
#define IDS_MSG_BODY_APPLICATIONBASE    132
#define IDS_MSG_BODY_APPDOMAIN          133
#define IDS_MSG_BODY_MISSINGEXCELDNALOADER 134
#define IDS_MSG_BODY_EXCELDNALOADER     135
#define IDS_MSG_BODY_EXCELDNALOADERNAME 136
#define IDS_MSG_BODY_XLADDIN            137
#define IDS_MSG_BODY_XLADDININIT        138

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
